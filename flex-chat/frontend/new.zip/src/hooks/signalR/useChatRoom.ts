import { useEffect } from "react";

import { SIGNALR_SERVER_EVENTS } from "../../constants/signalR/signalREvents";
import { getConnection } from "../../services/signalRService";

export const useChatRoom = (chatId?: number | null) => {
  useEffect(() => {
    if (!chatId) return;

    const conn = getConnection();
    if (!conn) return;

    conn.invoke(SIGNALR_SERVER_EVENTS.JOIN_CHAT, chatId)
      .then(() => console.log("Joined chat:", chatId))
      .catch(console.error);

    return () => {
      conn.invoke(SIGNALR_SERVER_EVENTS.LEAVE_CHAT, chatId)
        .then(() => console.log("Left chat:", chatId))
        .catch(console.error);
    };
  }, [chatId]);
};