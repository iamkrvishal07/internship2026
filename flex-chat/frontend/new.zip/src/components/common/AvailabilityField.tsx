import { useEffect, useState } from "react";

import { DEFAULT_DEBOUNCE_DELAY } from "../../constants/defaults";

// ── Props ──
type AvailabilityFieldProps = {
  label: string;
  value: string;
  onChange: (value: string) => void;
  checkFn: (value: string) => Promise<boolean> | boolean;
  registration: any;
  error?: string;
  minLength?: number;
  successMessage?: string;
  errorMessage?: string;
};

const AvailabilityField = ({
  label,
  value,
  onChange,
  checkFn,
  registration,
  error,
  minLength = 3,
  successMessage = "Available!",
  errorMessage = "Already taken!",
}: AvailabilityFieldProps) => {
  // ── State ──
  const [isAvailable, setIsAvailable] = useState<boolean | null>(null);
  const [isChecking, setIsChecking] = useState(false);
  const [lastChecked, setLastChecked] = useState<string | null>(null);

  // ── Effects ──
  useEffect(() => {
    if (
      !value ||
      value.trim().length < minLength ||
      value === lastChecked
    ) {
      return;
    }

    setIsChecking(true);
    setIsAvailable(null);

    const timeout = setTimeout(async () => {
      try {
        const result = await checkFn(value);
        setIsAvailable(result);
        setLastChecked(value);
      } catch {
        setIsAvailable(null);
      } finally {
        setIsChecking(false);
      }
    }, DEFAULT_DEBOUNCE_DELAY);

    return () => clearTimeout(timeout);
  }, [value, checkFn, minLength, lastChecked]);

  // ── Render ──
  return (
    <div className="w-full">
      <input
        type="text"
        value={value}
        placeholder={label}
        {...registration}
        onChange={(e) => {
          registration.onChange(e);
          onChange(e.target.value);
        }}
        className={`block w-full px-4 py-3 text-sm text-gray-900 bg-gray-50 border rounded-xl outline-none transition-all
          ${
            error
              ? "border-red-400 focus:ring-red-100"
              : isAvailable === false
                ? "border-red-400 focus:ring-red-100"
                : isAvailable === true
                  ? "border-green-400 focus:ring-green-100"
                  : "border-gray-200 focus:border-gray-400 focus:ring-gray-100"
          }
          placeholder-gray-400 focus:ring-2`}
      />

      <div className="h-5 mt-1 flex items-center gap-1 text-xs">
        {error && <span className="text-red-500">{error}</span>}

        {!error && isChecking && (
          <span className="text-gray-400 flex items-center gap-1">
            <svg
              className="animate-spin w-3 h-3"
              viewBox="0 0 24 24"
              fill="none"
            >
              <circle
                className="opacity-25"
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="4"
              />
              <path
                className="opacity-75"
                fill="currentColor"
                d="M4 12a8 8 0 018-8v8z"
              />
            </svg>
            Checking...
          </span>
        )}

        {!error && !isChecking && isAvailable === true && (
          <span className="text-green-500 flex items-center gap-1">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
              <path
                d="M5 12l5 5L19 7"
                stroke="currentColor"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            {successMessage}
          </span>
        )}

        {!error && !isChecking && isAvailable === false && (
          <span className="text-red-500">{errorMessage}</span>
        )}
      </div>
    </div>
  );
};

export default AvailabilityField;