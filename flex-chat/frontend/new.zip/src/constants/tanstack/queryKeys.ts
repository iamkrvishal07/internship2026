import { STALE_TIME_5_MIN } from "../../constants/defaults";

export { STALE_TIME_5_MIN as STALE_TIME };

export const QUERY_KEYS = {
    USERS: 'users',
    USER_PROFILE: 'my_profile',
    CHECK_USERNAME: 'check-username',
    CHECK_EMAIL: 'check-email',
};