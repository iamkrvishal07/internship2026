import React, { useEffect, useRef,useState } from "react";

import { HiCheck,HiX } from "react-icons/hi";
import { toast } from "react-toastify";

import { SEARCH_DEBOUNCE_DELAY } from "../../constants/defaults";
import { useCreateGroupChat } from "../../hooks/tanstackQuery/useGroupChat";
import { useFetchUsers } from "../../hooks/tanstackQuery/useUserApi";
import useFuncDebounce from "../../hooks/useDebounce";

import type { User } from "../../types/user";

// ── Constants ──
const AVATAR_PALETTE = [
  "bg-violet-100 text-violet-700",
  "bg-sky-100 text-sky-700",
  "bg-emerald-100 text-emerald-700",
  "bg-amber-100 text-amber-700",
  "bg-rose-100 text-rose-700",
  "bg-indigo-100 text-indigo-700",
];

// ── Helpers ──
function colorFor(id: number) {
  return AVATAR_PALETTE[id % AVATAR_PALETTE.length];
}

function initials(name: string) {
  return name
    .split(" ")
    .map((w) => w[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

// ── Sub-components ──
function Avatar({
  user,
  size = "md",
}: {
  user: { id: number; fullName?: string; username: string; avatarUrl?: string | null };
  size?: "sm" | "md" | "lg";
}) {
  const dim =
    size === "lg"
      ? "w-20 h-20 text-2xl"
      : size === "sm"
        ? "w-8 h-8 text-xs"
        : "w-10 h-10 text-sm";

  if (user.avatarUrl) {
    return (
      <img
        src={user.avatarUrl}
        alt={user.fullName || user.username}
        className={`${dim} rounded-full object-cover shrink-0`}
      />
    );
  }
  return (
    <span
      className={`${dim} rounded-full flex items-center justify-center font-bold shrink-0 ${colorFor(user.id)}`}
    >
      {initials(user.fullName || user.username)}
    </span>
  );
}

// ── Props ──
interface CreateGroupModalProps {
  onClose: () => void;
  currentUserId: number | null;
}

// ── Component ──
const CreateGroupModal = ({ onClose, currentUserId }: CreateGroupModalProps) => {
  // ── State ──
  const [step, setStep] = useState<1 | 2>(1);
  const [groupName, setGroupName] = useState("");
  const [description, setDescription] = useState("");
  const [selected, setSelected] = useState<User[]>([]);
  const [debounceSearch, setDebounceSearch] = useState("");
  const [nameError, setNameError] = useState("");

  // ── Refs ──
  const sentinelRef = useRef<HTMLDivElement>(null);

  // ── Query hooks ──
  const {
    data,
    isLoading,
    isFetchingNextPage,
    hasNextPage,
    fetchNextPage,
  } = useFetchUsers(debounceSearch);

  const { mutate: createGroup, isPending } = useCreateGroupChat();

  // ── Derived state ──
  const users = data?.pages.flatMap((p) => p.items) ?? [];

  // ── Effects ──
  useEffect(() => {
    const sentinel = sentinelRef.current;
    if (!sentinel) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasNextPage && !isFetchingNextPage) {
          fetchNextPage();
        }
      },
      { threshold: 0.1 },
    );

    observer.observe(sentinel);
    return () => observer.disconnect();
  }, [hasNextPage, isFetchingNextPage, fetchNextPage]);

  // ── Handlers ──
  const handleDebounceSearchTermChange = useFuncDebounce((searchValue) => {
    setDebounceSearch(searchValue);
  }, SEARCH_DEBOUNCE_DELAY);

  const toggle = (user: User) => {
    setSelected((prev) =>
      prev.find((u) => u.id === user.id)
        ? prev.filter((u) => u.id !== user.id)
        : [...prev, user],
    );
  };

  const handleCreate = () => {
    if (!groupName.trim()) {
      setNameError("Group name is required.");
      return;
    }
    setNameError("");
    createGroup(
      {
        name: groupName.trim(),
        description: description.trim(),
        memberIds: selected.map((u) => u.id),
      },
      {
        onSuccess: () => {
          toast.success("Group created successfully!");
          onClose();
        },
      },
    );
  };

  const handleAvatarFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    // Placeholder for avatar upload logic
    toast.info("Avatar upload is not implemented yet.");
  };

  // ── Return ──
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-white sticky top-0 z-10">
          <div>
            <h2 className="text-xl font-bold text-gray-900">
              {step === 1 ? "Create Group" : "Group Details"}
            </h2>
            <p className="text-xs text-gray-500 mt-0.5">
              {step === 1
                ? `Selected ${selected.length} members`
                : "Add a name and optional photo"}
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full text-gray-400 hover:bg-gray-100 transition-colors"
          >
            <HiX size={20} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto">
          {step === 1 ? (
            <div className="flex flex-col h-full">
              <div className="p-4 border-b border-gray-50">
                <div className="relative">
                  <svg
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                    width="16"
                    height="16"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    viewBox="0 0 24 24"
                  >
                    <circle cx="11" cy="11" r="8" />
                    <path strokeLinecap="round" d="M21 21l-4.35-4.35" />
                  </svg>
                  <input
                    type="text"
                    placeholder="Search users..."
                    onChange={(e) =>
                      handleDebounceSearchTermChange(e.target.value)
                    }
                    className="w-full pl-10 pr-4 py-2.5 bg-gray-100 border-none rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 transition-all"
                  />
                </div>
              </div>

              {selected.length > 0 && (
                <div className="px-4 py-3 bg-indigo-50/50 border-b border-indigo-100 flex gap-2 overflow-x-auto no-scrollbar">
                  {selected.map((u) => (
                    <div key={u.id} className="relative shrink-0 group">
                      <Avatar user={u} size="sm" />
                      <button
                        onClick={() => toggle(u)}
                        className="absolute -top-1 -right-1 w-4 h-4 bg-gray-900 text-white rounded-full flex items-center justify-center border border-white hover:bg-red-500 transition-colors"
                      >
                        <HiX size={10} />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex-1">
                {isLoading && users.length === 0 ? (
                  <div className="flex justify-center py-10">
                    <div className="animate-spin w-6 h-6 border-2 border-indigo-500 border-t-transparent rounded-full" />
                  </div>
                ) : (
                  <div className="divide-y divide-gray-50">
                    {users
                      .filter((u) => u.id !== currentUserId)
                      .map((u) => {
                        const isSelected = selected.some((s) => s.id === u.id);
                        return (
                          <div
                            key={u.id}
                            onClick={() => toggle(u)}
                            className="px-6 py-3 flex items-center gap-3 hover:bg-gray-50 cursor-pointer transition-colors"
                          >
                            <div className="relative">
                              <Avatar user={u} />
                              {isSelected && (
                                <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-indigo-600 text-white rounded-full flex items-center justify-center border-2 border-white">
                                  <HiCheck size={12} />
                                </div>
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-semibold text-gray-900 truncate">
                                {u.fullName || u.username}
                              </p>
                              <p className="text-xs text-gray-400">
                                @{u.username}
                              </p>
                            </div>
                          </div>
                        );
                      })}
                    <div ref={sentinelRef} className="h-4" />
                    {isFetchingNextPage && (
                      <div className="py-4 flex justify-center">
                        <div className="w-5 h-5 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="p-8 space-y-8">
              <div className="flex flex-col items-center">
                <div className="relative group">
                  <div className="w-24 h-24 rounded-full bg-gray-100 flex items-center justify-center border-2 border-dashed border-gray-300 overflow-hidden">
                    <svg
                      width="32"
                      height="32"
                      className="text-gray-400"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M6.827 6.175A2.31 2.31 0 015.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 00-1.134-.175 2.31 2.31 0 01-1.64-1.055l-.822-1.316a2.192 2.192 0 00-1.736-1.039 48.774 48.774 0 00-5.232 0 2.192 2.192 0 00-1.736 1.039l-.821 1.316z"
                      />
                      <circle cx="12" cy="13" r="3" />
                    </svg>
                  </div>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleAvatarFile}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                  <div className="absolute -bottom-1 -right-1 w-8 h-8 bg-indigo-600 text-white rounded-full flex items-center justify-center border-4 border-white shadow-lg">
                    <svg width="14" height="14" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 4v16m8-8H4" stroke="white" strokeWidth="3" strokeLinecap="round" />
                    </svg>
                  </div>
                </div>
              </div>

              <div className="space-y-5">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 px-1">
                    Group Name
                  </label>
                  <input
                    autoFocus
                    type="text"
                    placeholder="Enter group name..."
                    value={groupName}
                    onChange={(e) => {
                      setGroupName(e.target.value);
                      if (e.target.value.trim()) setNameError("");
                    }}
                    className={`w-full px-4 py-3 bg-gray-50 border rounded-xl text-sm outline-none transition-all focus:ring-2
                      ${
                        nameError
                          ? "border-red-400 focus:ring-red-100"
                          : "border-gray-100 focus:border-indigo-400 focus:ring-indigo-100"
                      }`}
                  />
                  {nameError && (
                    <p className="mt-1.5 text-xs text-red-500 font-medium px-1">
                      {nameError}
                    </p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 px-1">
                    Description (Optional)
                  </label>
                  <textarea
                    placeholder="What is this group about?"
                    rows={3}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm outline-none focus:border-indigo-400 focus:ring-2 focus:ring-indigo-100 transition-all resize-none"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="p-6 bg-white border-t border-gray-100 sticky bottom-0 z-10 flex gap-3">
          {step === 1 ? (
            <button
              onClick={() => setStep(2)}
              disabled={selected.length === 0}
              className="flex-1 h-12 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 active:scale-[0.98] transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-indigo-200"
            >
              Next Step
            </button>
          ) : (
            <>
              <button
                onClick={() => setStep(1)}
                className="w-24 h-12 border border-gray-200 text-gray-600 font-bold rounded-xl hover:bg-gray-50 transition-colors"
              >
                Back
              </button>
              <button
                onClick={handleCreate}
                disabled={isPending || !groupName.trim()}
                className="flex-1 h-12 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 active:scale-[0.98] transition-all disabled:opacity-50 shadow-lg shadow-indigo-200"
              >
                {isPending ? (
                  <span className="flex items-center justify-center gap-2">
                    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      />
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8v8z"
                      />
                    </svg>
                    Creating...
                  </span>
                ) : (
                  "Create Group"
                )}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default CreateGroupModal;