import { useCallback,useEffect, useMemo, useRef, useState } from "react";

import * as signalR from "@microsoft/signalr";
import EmojiPicker from "emoji-picker-react";
import { HiArrowLeft, HiDotsVertical,HiPaperAirplane } from "react-icons/hi";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

import Loader from "../../components/common/Loader";
import MessageInfoModal from "../../components/message/MessageInfoModal";
import MessageItem from "../../components/message/MessageItem";
import { getDefaultAvatar, getDefaultGroupAvatar, TYPING_STOP_DELAY } from "../../constants/defaults";
import {
  chatKeys,
  useGetChatById,
  useGetMessages,
} from "../../hooks/tanstackQuery/useChatApi";
import { useGetUsers } from "../../hooks/tanstackQuery/useUserApi";
import { useCurrentUserId } from "../../hooks/useCurrentUserId";
import useFuncDebounce from "../../hooks/useDebounce";
import useQueryParams from "../../hooks/useQueryParams";
import {
  acknowledgeDelivery,
  deleteMessageViaSignalR,
  editMessageViaSignalR,
  getConnection,
  markMessagesRead,
  sendMessageViaSignalR,
  sendTypingIndicator,
} from "../../services/signalRService";
import { usePendingMessagesStore } from "../../stores/pendingMessageStore";
import { usePresenceStore } from "../../stores/presenceStore";
import { useTypingStore } from "../../stores/typingStore";
import { updateMessagesCacheTyped } from "../../utils/messageCacheUtils";
import { queryClient } from "../../utils/queryClient";
import GroupProfilePanel from "./GroupProfilePanel";

import type { Message } from "../../types/message";
import type { EmojiClickData } from "emoji-picker-react";

// ── Component ──
const ChatPage = () => {
  // ── Query params ──
  const { chatId } = useQueryParams<{ chatId: string }>();

  // ── Store hooks ──
  const typingUser = useTypingStore(
    (s) => s.typingByChatId[chatId ? parseInt(chatId) : 0] ?? null,
  );
  const pendingCount = usePendingMessagesStore(
    (s) => s.pending.filter((m) => m.chatId === parseInt(chatId ?? "0")).length,
  );
  const isOnline = usePresenceStore((s) => s.isOnline);

  // ── Router / identity ──
  const navigate = useNavigate();
  const currentUserId = useCurrentUserId();
  const currentUserName = "user";

  // ── Local state ──
  const [messageText, setMessageText] = useState("");
  const [showGroupPanel, setShowGroupPanel] = useState(false);
  const [selectedMessage, setSelectedMessage] = useState<Message | null>(null);
  const [infoModalOpen, setInfoModalOpen] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  // ── Refs ──
  const pickerRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const sentinelRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const isFirstLoad = useRef(true);
  const prevScrollHeightRef = useRef<number>(0);

  // ── Query hooks ──
  const { data: chat, isLoading: chatLoading } = useGetChatById(
    chatId ? parseInt(chatId) : null,
  );

  const {
    data: messagesData,
    isLoading: messagesLoading,
    isFetchingNextPage,
    hasNextPage,
    fetchNextPage,
  } = useGetMessages(chatId ? parseInt(chatId) : null);

  const { data: allUsersRaw = [] } = useGetUsers();

  // ── Derived state ──
  const messages = useMemo(() => {
    return (messagesData?.pages ?? [])
      .slice()
      .reverse()
      .flatMap((p) => p.messages);
  }, [messagesData]);

  const allUsers = Array.isArray(allUsersRaw)
    ? allUsersRaw
    : ((allUsersRaw as any).items ?? (allUsersRaw as any).data ?? []);

  const mine = chat?.members?.find((m: any) => m.userId === currentUserId);
  const mineAvatar =
    mine?.avatarUrl || getDefaultAvatar(currentUserId);

  // ── Effects ──
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (pickerRef.current && !pickerRef.current.contains(e.target as Node)) {
        setShowEmojiPicker(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  useEffect(() => {
    if (!messages.length) return;
    const container = containerRef.current;
    if (!container) return;

    if (isFirstLoad.current) {
      container.scrollTop = container.scrollHeight;
      isFirstLoad.current = false;
      return;
    }

    if (prevScrollHeightRef.current > 0) {
      const diff = container.scrollHeight - prevScrollHeightRef.current;
      container.scrollTop += diff;
      prevScrollHeightRef.current = 0;
      return;
    }

    const isNearBottom =
      container.scrollHeight - container.scrollTop - container.clientHeight < 120;
    if (isNearBottom) {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages.length]);

  useEffect(() => {
    if (!messages?.length) return;

    messages.forEach((message) => {
      const alreadyDelivered =
        message.receipt?.deliveredUserIds?.includes(currentUserId);
      const isIncoming = message.senderId !== currentUserId;
      if (isIncoming && !alreadyDelivered) {
        acknowledgeDelivery(message.id);
      }
    });

    const others = messages.filter((m) => m.senderId !== currentUserId);
    if (others.length === 0) return;

    const lastReadMessageId = Math.max(...others.map((m) => m.id));
    markMessagesRead(parseInt(chatId!), lastReadMessageId);

    queryClient.setQueryData<any[]>(
      chatKeys.list(),
      (old) =>
        old?.map((c) =>
          c.id === parseInt(chatId!) ? { ...c, unreadCount: 0 } : c,
        ) ?? old,
    );
  }, [messagesData]);

  useEffect(() => {
    isFirstLoad.current = true;
    prevScrollHeightRef.current = 0;
    setShowGroupPanel(false);
  }, [chatId]);

  useEffect(() => {
    const sentinel = sentinelRef.current;
    const container = containerRef.current;
    if (!sentinel || !container) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasNextPage && !isFetchingNextPage) {
          prevScrollHeightRef.current = container.scrollHeight;
          fetchNextPage();
        }
      },
      { root: container, threshold: 0.1 },
    );

    observer.observe(sentinel);
    return () => observer.disconnect();
  }, [hasNextPage, isFetchingNextPage, fetchNextPage]);

  // ── Handlers ──
  const handleEmojiSelect = (emojiData: EmojiClickData) => {
    const native = emojiData.emoji;
    const textarea = textareaRef.current;

    if (textarea) {
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const newText =
        messageText.slice(0, start) + native + messageText.slice(end);
      setMessageText(newText);
      setTimeout(() => {
        textarea.focus();
        textarea.setSelectionRange(
          start + native.length,
          start + native.length,
        );
      }, 0);
    } else {
      setMessageText((prev) => prev + native);
    }
  };

  const handleOpenInfo = useCallback((message: Message) => {
    setSelectedMessage(message);
    setInfoModalOpen(true);
  }, []);

  const stopTypingDebounced = useFuncDebounce(() => {
    if (!chatId) return;
    sendTypingIndicator(parseInt(chatId), currentUserName, false);
  }, TYPING_STOP_DELAY);

  const handleTyping = (value: string) => {
    setMessageText(value);
    if (!chatId || !chat) return;
    sendTypingIndicator(parseInt(chatId), currentUserName, true);
    stopTypingDebounced();
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim() || !chatId) return;

    const tempId = -Date.now();
    const optimisticMessage: Message = {
      id: tempId,
      chatId: parseInt(chatId),
      senderId: currentUserId,
      senderName: currentUserName,
      senderAvatarUrl: mineAvatar,
      content: messageText.trim(),
      contentType: "text",
      createdAt: new Date().toISOString(),
      isDeleted: false,
      isEdited: false,
      status: "sending",
      receipt: { deliveredUserIds: [], readUserIds: [] },
    };

    updateMessagesCacheTyped(parseInt(chatId), (msgs) => [...msgs, optimisticMessage]);

    setMessageText("");

    const conn = getConnection();
    const isOffline = !conn || conn.state !== signalR.HubConnectionState.Connected;

    if (isOffline) {
      usePendingMessagesStore.getState().addPending({
        tempId,
        chatId: parseInt(chatId),
        content: optimisticMessage.content,
        contentType: "text",
        createdAt: optimisticMessage.createdAt,
      });
      toast.warn("You're offline. Message will be sent when reconnected.", {
        toastId: "offline-warning",
      });
      return;
    }

    try {
      await sendMessageViaSignalR(parseInt(chatId), optimisticMessage.content, "text");
    } catch {
      updateMessagesCacheTyped(parseInt(chatId), (msgs) =>
        msgs.filter((m) => m.id !== tempId),
      );
      usePendingMessagesStore.getState().addPending({
        tempId,
        chatId: parseInt(chatId),
        content: optimisticMessage.content,
        contentType: "text",
        createdAt: optimisticMessage.createdAt,
      });
      toast.error("Failed to send. Will retry when connected.", {
        toastId: "sending-failed",
      });
    }
  };

  const handleEdit = useCallback(
    async (message: Message, newContent: string) => {
      updateMessagesCacheTyped(parseInt(chatId!), (msgs) =>
        msgs.map((m) =>
          m.id === message.id
            ? {
                ...m,
                content: newContent,
                isEdited: true,
                editedAt: new Date().toISOString(),
              }
            : m,
        ),
      );

      try {
        await editMessageViaSignalR(message.id, newContent);
      } catch {
        updateMessagesCacheTyped(parseInt(chatId!), (msgs) =>
          msgs.map((m) => (m.id === message.id ? message : m)),
        );
        toast.error("Failed to edit message");
      }
    },
    [chatId],
  );

  const handleDelete = useCallback(
    async (message: Message) => {
      updateMessagesCacheTyped(parseInt(chatId!), (msgs) =>
        msgs.map((m) =>
          m.id === message.id ? { ...m, isDeleted: true } : m,
        ),
      );

      try {
        await deleteMessageViaSignalR(message.id);
      } catch {
        updateMessagesCacheTyped(parseInt(chatId!), (msgs) =>
          msgs.map((m) => (m.id === message.id ? message : m)),
        );
        toast.error("Failed to delete message");
      }
    },
    [chatId],
  );

  // ── Render helpers ──
  if (chatLoading || messagesLoading) return <Loader />;

  if (!chatId || !chat) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <HiDotsVertical size={24} className="text-gray-300" />
          </div>
          <p className="text-gray-400 text-sm">
            Select a chat to start messaging
          </p>
        </div>
      </div>
    );
  }

  const isGroup = chat.type === "Group";
  const otherMember = !isGroup
    ? chat?.members?.find((m: any) => m.userId !== currentUserId)
    : null;

  const otherMemberId = otherMember?.userId;
  const isOtherOnline = otherMemberId ? isOnline(otherMemberId) : false;
  const chatName = isGroup
    ? chat.name || "Unnamed Group"
    : otherMember?.fullName || "Unknown User";

  const chatAvatar = isGroup
    ? chat.imageUrl || getDefaultGroupAvatar(chatName)
    : otherMember?.avatarUrl || getDefaultAvatar(otherMember?.fullName);

  const groupMembers = isGroup
    ? chat.members
        ?.filter((m: any) => m.userId !== currentUserId)
        .map((m: any) => ({
          userId: m.userId,
          fullName: m.fullName,
          avatarUrl: m.avatarUrl,
        }))
    : null;

  // ── Return ──
  return (
    <div className="flex h-screen bg-white overflow-hidden">
      <div className="flex flex-col flex-1 overflow-hidden">
        <div className="flex items-center gap-3 px-4 py-3 bg-white border-b border-gray-100 flex-shrink-0">
          <button
            onClick={() => navigate(-1)}
            className="w-9 h-9 flex items-center justify-center rounded-lg text-gray-400 hover:bg-gray-100 hover:text-gray-700 transition-colors"
          >
            <HiArrowLeft size={20} />
          </button>

          <img
            src={chatAvatar}
            alt={chatName}
            className="w-10 h-10 rounded-full object-cover"
          />

          <div className="flex-1 min-w-0">
            <h2 className="text-[15px] font-medium text-gray-900 truncate">
              {chatName}
            </h2>

            {isGroup ? (
              <p className="text-xs text-gray-400 mt-0.5">
                {chat.members?.filter((m: any) => m.leftAt === null).length}{" "}
                members
              </p>
            ) : (
              <p
                className={`text-xs font-medium mt-0.5 ${
                  isOtherOnline ? "text-green-500" : "text-gray-400"
                }`}
              >
                {isOtherOnline ? "Online" : "Offline"}
              </p>
            )}
          </div>

          {isGroup && (
            <button
              onClick={() => setShowGroupPanel((v) => !v)}
              className={`w-9 h-9 flex items-center justify-center rounded-lg transition-colors ${
                showGroupPanel
                  ? "bg-indigo-50 text-indigo-500"
                  : "text-gray-400 hover:bg-gray-100"
              }`}
            >
              <HiDotsVertical size={20} />
            </button>
          )}
        </div>

        <div
          ref={containerRef}
          className="flex-1 overflow-y-auto px-4 py-4 flex flex-col gap-1 bg-gray-50"
        >
          <div ref={sentinelRef} className="h-1" />

          {isFetchingNextPage && (
            <div className="flex justify-center py-2">
              <div className="flex gap-1">
                <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce [animation-delay:0ms]" />
                <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce [animation-delay:150ms]" />
                <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce [animation-delay:300ms]" />
              </div>
            </div>
          )}

          {!hasNextPage && messages.length > 0 && (
            <p className="text-center text-xs text-gray-400 py-2">
              Start of conversation
            </p>
          )}

          {messages.length === 0 ? (
            <div className="flex items-center justify-center h-full">
              <p className="text-gray-400 text-sm">
                No messages yet. Start the conversation!
              </p>
            </div>
          ) : (
            messages.map((message) => (
              <MessageItem
                key={message.id}
                message={message}
                currentUserId={currentUserId}
                isOwn={message.senderId === currentUserId}
                totalMembers={
                  isGroup
                    ? (chat.members?.filter((m: any) => m.leftAt === null).length ?? 1)
                    : undefined
                }
                onInfoClick={handleOpenInfo}
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            ))
          )}

          <div ref={messagesEndRef} />
        </div>

        {typingUser && (
          <div className="flex items-center gap-2 px-4 py-2 bg-white border-t border-gray-100 text-xs text-gray-400 italic">
            <span className="flex gap-0.5">
              <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce [animation-delay:0ms]" />
              <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce [animation-delay:150ms]" />
              <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce [animation-delay:300ms]" />
            </span>
            {isGroup
              ? `${typingUser ?? "Someone"} is typing`
              : "typing..."}{" "}
          </div>
        )}

        {pendingCount > 0 && (
          <div className="flex items-center gap-2 px-4 py-1.5 bg-amber-50 border-t border-amber-100 text-xs text-amber-600">
            <svg
              width="13"
              height="13"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <circle cx="12" cy="12" r="10" />
              <path strokeLinecap="round" d="M12 8v4m0 4h.01" />
            </svg>
            {pendingCount} message{pendingCount > 1 ? "s" : ""} pending — will
            send when reconnected
          </div>
        )}

        <form
          onSubmit={handleSendMessage}
          className="flex items-center gap-2 px-4 py-2.5 bg-white border-t border-gray-100 shrink-0"
        >
          <button
            type="button"
            className="w-9 h-9 flex items-center justify-center rounded-full text-gray-400 hover:bg-gray-100 hover:text-gray-600 transition-colors"
          >
            <svg
              width="18"
              height="18"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"
              />
            </svg>
          </button>

          <div className="flex-1 relative flex items-center">
            <textarea
              ref={textareaRef}
              value={messageText}
              onChange={(e) => handleTyping(e.target.value)}
              placeholder="Type a message..."
              rows={1}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  if (messageText.trim()) {
                    handleSendMessage(e as any);
                  }
                }
              }}
              className="w-full max-h-32 min-h-[40px] pl-4 pr-10 py-2 bg-gray-100 rounded-2xl text-sm text-gray-900 placeholder-gray-400 border-none outline-none resize-none focus:bg-gray-200/70 transition-colors overflow-y-auto"
            />

            <button
              type="button"
              onClick={() => setShowEmojiPicker((p) => !p)}
              className="absolute right-2 text-gray-400 hover:text-yellow-500 transition-colors"
              aria-label="Emoji picker"
            >
              <svg
                width="18"
                height="18"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.8"
              >
                <circle cx="12" cy="12" r="10" />
                <path strokeLinecap="round" d="M8 14s1.5 2 4 2 4-2 4-2" />
                <line
                  x1="9"
                  y1="9"
                  x2="9.01"
                  y2="9"
                  strokeWidth="3"
                  strokeLinecap="round"
                />
                <line
                  x1="15"
                  y1="9"
                  x2="15.01"
                  y2="9"
                  strokeWidth="3"
                  strokeLinecap="round"
                />
              </svg>
            </button>

            {showEmojiPicker && (
              <div
                ref={pickerRef}
                className="absolute bottom-[calc(100%+6px)] right-0 z-50 shadow-xl rounded-2xl overflow-hidden"
              >
                <EmojiPicker
                  onEmojiClick={handleEmojiSelect}
                  skinTonesDisabled
                  previewConfig={{ showPreview: false }}
                  height={380}
                  width={320}
                />
              </div>
            )}
          </div>

          <button
            type="submit"
            disabled={!messageText.trim()}
            className="w-10 h-10 flex items-center justify-center rounded-full bg-indigo-500 text-white hover:bg-indigo-600 active:scale-95 transition-all disabled:bg-gray-200 disabled:text-gray-400 disabled:cursor-not-allowed flex-shrink-0"
          >
            <HiPaperAirplane size={18} />
          </button>
        </form>
      </div>

      {isGroup && showGroupPanel && (
        <GroupProfilePanel
          chat={chat}
          currentUserId={currentUserId}
          onClose={() => setShowGroupPanel(false)}
          allUsers={allUsers}
        />
      )}

      {infoModalOpen && selectedMessage && (
        <MessageInfoModal
          message={selectedMessage}
          members={chat?.members
            .map((m: any) => ({
              userId: m.userId,
              fullName: m.fullName,
              avatarUrl: m.avatarUrl,
            }))}
          currentUserId={currentUserId}
          onClose={() => {
            setInfoModalOpen(false);
            setSelectedMessage(null);
          }}
        />
      )}
    </div>
  );
};

export default ChatPage;
