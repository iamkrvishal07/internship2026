import { useEffect,useState } from "react";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { CgProfile } from "react-icons/cg";
import { HiOutlineFaceSmile, HiOutlineIdentification } from "react-icons/hi2";
import { MdCalendarMonth,MdEmail } from "react-icons/md";
import z from "zod";

import Loader from "../../components/common/Loader";
import Button from "../../components/ui/Button";
import Input from "../../components/ui/Input";
import { PLACEHOLDER_AVATAR_URL } from "../../constants/defaults";
import { useFetchUserProfile, useUpdateUserProfile } from "../../hooks/tanstackQuery/useUserApi";
import { userProfileSchema } from "../../schemas/userProfileSchema";

import type { ReactElement } from "react";
import type { UseFormRegister } from "react-hook-form";

// ── Types ──
type UserProfile = z.infer<typeof userProfileSchema>;

interface RowProps {
  icon?: React.ReactNode;
  type?: string;
  label: string;
  name: keyof UserProfile | null;
  value: string;
  register?: UseFormRegister<UserProfile>;
  error?: string | null;
  children?: ReactElement;
  isEditable?: boolean;
}

// ── Sub-component ──
const Row = ({
  icon,
  type = "text",
  label,
  name = null,
  value,
  register,
  error,
  isEditable = false,
  children,
}: RowProps) => (
  <div className="flex items-center justify-center gap-3 py-3 border-b border-[#2a2a40] last:border-0">
    {children ?? (
      <>
        <span className="mt-3 text-gray-400">{icon}</span>

        <div className="flex-1">
          <p className="mb-2 text-xs text-gray-500">{label}</p>

          <Input
            type={type}
            name={name}
            value={value}
            register={register}
            error={error}
            isEditable={isEditable}
          />
        </div>
      </>
    )}
  </div>
);

// ── Component ──
const UserProfilePage = () => {
  // ── State ──
  const [isEditMode, setIsEditMode] = useState(false);

  // ── Query hooks ──
  const { data, isLoading } = useFetchUserProfile();
  const { mutate, isPending } = useUpdateUserProfile();

  // ── Form ──
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isDirty },
  } = useForm<UserProfile>({
    resolver: zodResolver(userProfileSchema),
  });

  // ── Effects ──
  useEffect(() => {
    if (data) {
      reset(data);
    }
  }, [data, reset]);

  // ── Handlers ──
  const onSubmit = (values: UserProfile) => {
    mutate(values, {
      onSuccess: () => {
        setIsEditMode(false);
      },
      onError: () => {
        setIsEditMode(false);
        reset(data);
      },
    });
  };

  const handleEditButtonClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    reset(data);
    setIsEditMode(true);
  };

  const handleCancelButtonClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    reset(data);
    setIsEditMode(false);
  };

  // ── Render helpers ──
  if (isLoading || isPending) return <Loader />;

  // ── Return ──
  return (
    <div className="min-h-screen bg-[#0f0f1a] p-6 text-white">
      <div className="mx-auto max-w-3xl rounded-3xl border border-[#2a2a40] bg-[#181825] p-6 shadow-xl">
        <div className="flex flex-col items-center gap-4 border-b border-[#2a2a40] pb-6 md:flex-row">
          <img
            src={data?.avatarUrl || PLACEHOLDER_AVATAR_URL}
            alt="avatar"
            className="h-28 w-28 rounded-full border-4 border-[#8e8ee7]/40 object-cover"
          />

          <div className="flex-1 text-center md:text-left">
            <h1 className="text-3xl font-bold">
              {data?.fullName || "Full Name"}
            </h1>

            <p className="mt-1 text-sm text-gray-400">
              @{data?.username || "username"}
            </p>

            <p className="mt-3 text-sm text-violet-200">
              {data?.bio || "No bio added"}
            </p>
          </div>

          <div>
            {!isEditMode ? (
              <Button type="button" onClick={handleEditButtonClick}>
                Edit
              </Button>
            ) : (
              <Button className="btn-error" onClick={handleCancelButtonClick}>
                Cancel
              </Button>
            )}
          </div>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="mt-6 rounded-2xl bg-[#12121c] p-4">
          <h2 className="mb-4 text-lg font-semibold">Account Information</h2>

          <Row
            icon={<MdEmail />}
            label="Email"
            name="email"
            value={data?.email || ""}
          />

          <Row
            icon={<CgProfile />}
            label="Full Name"
            name="fullName"
            value={data?.fullName || ""}
            register={register}
            isEditable={isEditMode}
            error={errors?.fullName?.message}
          />

          <Row
            icon={<HiOutlineIdentification />}
            label="Bio"
            name="bio"
            value={data?.bio || ""}
            register={register}
            isEditable={isEditMode}
            error={errors?.bio?.message}
          />

          <Row
            icon={<HiOutlineFaceSmile />}
            label="Status"
            name="statusMessage"
            value={data?.statusMessage || ""}
            register={register}
            isEditable={isEditMode}
            error={errors?.statusMessage?.message}
          />

          <Row
            icon={<MdCalendarMonth />}
            name={null}
            label="Joined On"
            value={data?.createdAt || ""}
          />

          {isEditMode && (
            <Row label="SubmitButton" name={null} value="" isEditable>
              <Button type="submit" disabled={!isDirty || isPending}>
                Save changes
              </Button>
            </Row>
          )}
        </form>
      </div>
    </div>
  );
};

export default UserProfilePage;