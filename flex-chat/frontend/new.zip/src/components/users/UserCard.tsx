import { getDefaultAvatar } from "../../constants/defaults";

import type { UserCardProps } from "../../types/user";

const UserCard = ({ user, isSelected, onClick }: UserCardProps) => {
  const displayName = user.fullName ?? user.username;
  const avatar =
    user.avatarUrl || getDefaultAvatar(user.username);

  return (
    <div
      onClick={onClick}
      className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-colors
        ${isSelected ? "bg-[#2a2a4a]" : "hover:bg-[#22223b]"}`}
    >
      <img
        src={avatar}
        alt={displayName}
        className="w-10 h-10 rounded-full object-cover"
      />
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-white truncate">{displayName}</p>
        {user.statusMessage && (
          <p className="text-xs text-gray-300 truncate">{user.statusMessage}</p>
        )}
      </div>
    </div>
  );
};

export default UserCard;