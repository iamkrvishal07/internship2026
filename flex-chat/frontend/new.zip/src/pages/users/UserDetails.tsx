import {
  HiChat,
  HiCursorClick,
  HiLocationMarker,
  HiMail,
} from "react-icons/hi";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

import { getDefaultAvatar } from "../../constants/defaults";
import routes from "../../constants/routes/routes";
import { useGetOrCreateDirectChat } from "../../hooks/tanstackQuery/useChatApi";

import type { User } from "../../types/user";

// ── Sub-components ──
const EmptyState = () => (
  <div className="flex-1 flex flex-col items-center justify-center text-center px-8">
    <HiCursorClick size={28} className="text-gray-400 mb-3" />
    <p className="text-gray-300">No profile selected</p>
    <p className="text-gray-500 text-sm">Select a user to view details</p>
  </div>
);

interface RowProps {
  icon: React.ReactNode;
  label: string;
  value: string;
}

const Row = ({ icon, label, value }: RowProps) => (
  <div className="flex items-center gap-3 py-3 border-b border-[#2a2a40] last:border-0">
    <span className="text-gray-400">{icon}</span>
    <div>
      <p className="text-xs text-gray-500">{label}</p>
      <p className="text-sm text-white truncate">{value}</p>
    </div>
  </div>
);

// ── Props ──
interface UserDetailsProps {
  user: User | null;
}

// ── Component ──
const UserDetails = ({ user }: UserDetailsProps) => {
  // ── Hooks ──
  const navigate = useNavigate();
  const createChatMutation = useGetOrCreateDirectChat();

  // ── Render helpers ──
  if (!user) return <EmptyState />;

  // ── Derived state ──
  const { avatarUrl, username, fullName, bio, statusMessage } = user;
  const avatar = avatarUrl || getDefaultAvatar(username);

  // ── Handlers ──
  const handleSendMessage = async () => {
    try {
      const chat = await createChatMutation.mutateAsync(user.id);
      navigate(`${routes.chats}?chat_id=${Number(chat.id)}`);
    } catch {
      toast.error("Failed to create chat");
    }
  };

  // ── Return ──
  return (
    <div className="flex-1 flex flex-col bg-[#151528] overflow-y-auto">
      <div className="h-24 bg-[#1f1f35]" />

      <div className="px-6 -mt-10">
        <img
          src={avatar}
          alt={username}
          className="w-20 h-20 rounded-xl border-4 border-[#151528]"
        />
      </div>

      <div className="px-6 py-4 border-b border-[#2a2a40]">
        <h2 className="text-white text-lg font-semibold">
          {fullName || username}
        </h2>
        <p className="text-gray-400 text-sm">@{username}</p>

        {bio && <p className="text-gray-300 text-sm mt-2">{bio}</p>}
      </div>

      <div className="px-6">
        <Row
          icon={<HiMail size={16} />}
          label="Full Name"
          value={fullName || "Not provided"}
        />
        {statusMessage && (
          <Row
            icon={<HiLocationMarker size={16} />}
            label="Status"
            value={statusMessage}
          />
        )}
        <Row
          icon={<HiChat size={16} />}
          label="Bio"
          value={bio || "No bio yet"}
        />
      </div>

      <div className="px-6 py-4 mt-auto space-y-2">
        <button
          onClick={handleSendMessage}
          disabled={createChatMutation.isPending}
          className="w-full py-2.5 rounded-lg bg-indigo-600 text-white text-sm hover:bg-indigo-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {createChatMutation.isPending ? "Opening chat..." : "Send message"}
        </button>

        <button className="w-full py-2.5 rounded-lg bg-[#1f1f35] text-gray-300 text-sm hover:bg-[#2a2a40] transition">
          Add contact
        </button>
      </div>
    </div>
  );
};

export default UserDetails;