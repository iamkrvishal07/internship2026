import { useEffect, useRef } from "react";

import { HiSearch } from "react-icons/hi";
import { MdOutlineClear } from "react-icons/md";

import UserCard from "../../components/users/UserCard";

import type { User } from "../../types/user";

// ── Props ──
interface UserListProps {
  list: User[];
  searchKey: string;
  selectedUserId: number | null;
  hasNextPage: boolean;
  isFetchingNextPage: boolean;
  onLoadMore: () => void;
  handleSearchKeyChange: (value: string) => void;
  handleUserSelect: (userId: number) => void;
}

// ── Component ──
const UserList = ({
  list = [],
  searchKey = "",
  selectedUserId,
  hasNextPage,
  isFetchingNextPage,
  onLoadMore,
  handleSearchKeyChange,
  handleUserSelect,
}: UserListProps) => {
  // ── Refs ──
  const sentinelRef = useRef<HTMLDivElement>(null);

  // ── Effects ──
  useEffect(() => {
    const sentinel = sentinelRef.current;
    if (!sentinel) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const first = entries[0];
        if (first.isIntersecting && hasNextPage && !isFetchingNextPage) {
          onLoadMore();
        }
      },
      { threshold: 0.1 }
    );

    observer.observe(sentinel);
    return () => observer.disconnect();
  }, [hasNextPage, isFetchingNextPage, onLoadMore]);

  // ── Return ──
  return (
    <div className="w-90 shrink-0 flex flex-col border-r border-[#2a2a40] bg-[#151528]">
      <div className="px-5 pt-5 pb-4 border-b border-[#2a2a40]">
        <h1 className="text-white font-semibold text-lg mb-4">Users</h1>
        <div className="flex items-center gap-2 bg-[#1f1f35] border border-[#2a2a40] rounded-lg px-3 py-2 mb-3">
          <HiSearch className="text-gray-400" size={15} />
          <input
            type="text"
            placeholder="Search users..."
            value={searchKey}
            onChange={(e) => handleSearchKeyChange(e.target.value)}
            className="bg-transparent text-sm text-white placeholder-gray-500 outline-none w-full"
          />
          {searchKey && (
            <button
              onClick={() => handleSearchKeyChange("")}
              className="text-gray-400 hover:text-white text-xs cursor-pointer"
            >
              <MdOutlineClear/>
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto py-3 px-3 space-y-2">
        {list.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500 text-sm">
              {searchKey ? `No results for "${searchKey}"` : "No users found"}
            </p>
          </div>
        ) : (
          <>
            {list.map((u) => (
              <UserCard
                key={u.id}
                user={u}
                isSelected={u.id === selectedUserId}
                onClick={() => handleUserSelect(u.id)}
              />
            ))}

            <div ref={sentinelRef} className="h-1" />

            {isFetchingNextPage && (
              <div className="flex justify-center py-3">
                <div className="flex gap-1">
                  <span className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce [animation-delay:0ms]" />
                  <span className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce [animation-delay:150ms]" />
                  <span className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce [animation-delay:300ms]" />
                </div>
              </div>
            )}

            {!hasNextPage && list.length > 0 && (
              <p className="text-center text-xs text-gray-600 py-2">
                All users loaded
              </p>
            )}
          </>
        )}
      </div>

      <div className="px-5 py-3 border-t border-[#2a2a40]">
        <p className="text-gray-500 text-xs">{list.length} users loaded</p>
      </div>
    </div>
  );
};

export default UserList;