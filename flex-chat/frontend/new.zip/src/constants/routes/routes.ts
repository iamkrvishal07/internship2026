const INDEX_ROUTE = "/";
const SIGNUP_ROUTE = "/signup";
const LOGIN_ROUTE = "/login";
const VERIFY_EMAIL_ROUTE = "/verify-email";
const USERS_ROUTE = "/users";
const MY_PROFILE_ROUTE = "/my-profile";
const CHAT_ROUTE = "/chat/:chatId";
const CHATS_ROUTE = "/chats";

const routes = {
  index: INDEX_ROUTE,
  signup: SIGNUP_ROUTE,
  login: LOGIN_ROUTE,
  verifyEmail: VERIFY_EMAIL_ROUTE,
  users: USERS_ROUTE,
  myProfile: MY_PROFILE_ROUTE,
  chat: CHAT_ROUTE,
  chats: CHATS_ROUTE,
};

export default routes;